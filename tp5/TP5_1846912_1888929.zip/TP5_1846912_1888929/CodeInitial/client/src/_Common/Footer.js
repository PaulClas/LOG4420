
export function Footer() {
  return (
    <footer>
        <p>Équipe 210 - Myriam Kiriakos 1888929 et Paul Clas 1846912</p>
    </footer>
  );
}

